# Create a Build for deploy project
npm run build

# deploy on netlify
netlify deploy --prod

# deploy on netlify directory
dist

# Run Development local server
npm run dev
